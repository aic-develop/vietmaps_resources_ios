#import <Foundation/Foundation.h>

//! Project version number for MapboxCoreNavigation.
FOUNDATION_EXPORT double MapboxCoreNavigationVersionNumber;

//! Project version string for MapboxCoreNavigation.
FOUNDATION_EXPORT const unsigned char MapboxCoreNavigationVersionString[];

#import "MBXAccounts+CoreNavigationAdditions.h"
