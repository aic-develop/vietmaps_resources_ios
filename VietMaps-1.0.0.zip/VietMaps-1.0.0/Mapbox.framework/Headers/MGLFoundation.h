#pragma once

#import <Foundation/Foundation.h>

#define MGL_EXPORT __attribute__((visibility ("default")))
